# # UpdateCustomerFiscalEntitiesResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | [**\DigitalFemsa\Model\CustomerAddress**](CustomerAddress.md) |  |
**tax_id** | **string** |  | [optional]
**email** | **string** |  | [optional]
**phone** | **string** |  | [optional]
**metadata** | **array<string,object>** |  | [optional]
**company_name** | **string** |  | [optional]
**id** | **string** |  |
**object** | **string** |  |
**created_at** | **int** |  |
**parent_id** | **string** |  | [optional]
**default** | **bool** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
